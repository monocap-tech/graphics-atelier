"""G06-P06: original contour/exposure vs analytic directional wake.
Run: python shearwake.py [output directory]. Requires Pillow and NumPy.
No external art, physical-simulation or game-runtime claims.
"""
import sys, json, math, hashlib
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import numpy as np

W,H,S,T = 160,90,4,48
BG=(15,24,34); PAL=[(49,81,103,255),(79,166,175,255),(186,233,217,255),(244,189,118,255)]
# Original individually authored polygon poses: (color role, x,y pairs).
# Each exposure is 4 ticks. No interpolation or shared analytic outline.
KEYS=[
 [],
 [(0,[22,47,29,40,46,44,36,49]),(1,[24,45,34,42,42,44,32,46])],
 [(0,[17,52,29,38,44,32,65,40,75,43,58,46,45,41,34,45,29,55]),(1,[29,44,43,35,59,40,71,43,57,43,44,39,35,44]),(2,[42,36,57,40,51,40])],
 [(0,[18,55,30,43,44,30,58,27,79,39,96,42,82,49,65,47,53,39,39,43,30,51]),(1,[29,46,46,33,58,30,80,41,92,42,79,45,59,39,51,35,42,38]),(2,[48,33,58,30,74,38,59,34]),(1,[21,58,29,54,25,60])],
 [(0,[21,57,40,41,55,28,71,25,91,34,116,40,109,51,92,55,79,48,68,37,54,41,40,51]),(1,[34,48,56,32,70,28,92,38,109,41,96,47,81,44,69,33,55,35]),(2,[58,30,70,28,92,38,79,35,70,31]),(3,[109,40,119,42,110,47]),(0,[30,62,41,60,37,65])],
 [(0,[30,58,49,46,64,33,83,27,99,30,121,35,136,43,127,52,109,57,91,50,83,42,65,46,52,55]),(1,[49,48,65,35,82,30,100,34,126,41,118,47,100,49,88,39,76,38,64,42]),(2,[82,30,99,34,117,39,101,37,92,33]),(3,[127,39,139,43,129,48]),(0,[37,65,46,62,42,68])],
 [(0,[43,60,60,49,75,38,95,39,104,46,99,54,81,49,64,52]),(1,[59,50,76,41,93,42,99,46,82,45]),(0,[111,36,127,34,142,39,148,43,135,50,117,47]),(1,[117,39,130,37,143,42,133,46,122,44]),(2,[131,38,145,42,138,43]),(3,[102,38,108,34,111,40]),(0,[48,65,57,63,52,69])],
 [(0,[58,61,74,48,91,49,108,57,99,61,85,55,73,57]),(1,[75,51,90,51,101,56,90,54]),(0,[119,31,131,28,144,31,152,38,140,43,127,39]),(1,[126,32,138,31,148,37,137,38]),(2,[141,33,149,36,145,38]),(0,[109,49,116,46,121,52,115,55]),(3,[105,37,110,34,112,38])],
 [(0,[75,62,86,55,97,56,106,64,94,64,84,60]),(1,[86,57,96,59,102,62,92,61]),(0,[130,24,141,22,153,29,149,34,137,32]),(1,[139,25,149,28,146,31]),(0,[120,47,128,43,133,47,128,51]),(3,[112,38,117,37,117,40])],
 [(0,[91,65,101,61,111,66,104,69]),(1,[101,63,108,66,104,67]),(0,[141,18,151,20,155,25,147,25]),(0,[131,45,138,45,141,48,136,50]),(0,[119,39,124,38,126,41])],
 [(0,[108,69,115,66,121,70,116,72]),(0,[148,15,156,19,152,21]),(0,[141,44,145,45,144,48])],
 []
]

def manual(t):
    im=Image.new('RGBA',(W,H));d=ImageDraw.Draw(im)
    for role,xy in KEYS[t//4]: d.polygon(list(zip(xy[::2],xy[1::2])), fill=PAL[role])
    return im

def procedural(t):
    im=Image.new('RGBA',(W,H));d=ImageDraw.Draw(im)
    # Independent analytic moving wave. At t=25 split into packets; no authored contours used.
    if t<4 or t>=44:return im
    u=(t-4)/40; head=36+119*u; length=12+61*math.sin(math.pi*u)**0.8
    def center(x):return 45+11*math.sin((x-head)/18+u*5)-5*math.sin(u*math.pi)
    def packet(a,b,scale,offset=0):
        if b-a<2:return
        xs=np.linspace(a,b,28);v=np.linspace(0,1,28)
        widths=(np.sin(np.pi*v)**0.66)*(4+8*math.sin(math.pi*u))*scale
        ys=[center(x)+offset for x in xs]
        for role,f,shift in [(0,1,0),(1,.58,-1.3),(2,.15,-2.0)]:
            p=[(float(x),float(y+shift-f*w)) for x,y,w in zip(xs,ys,widths)] + [(float(x),float(y+shift+f*w)) for x,y,w in reversed(list(zip(xs,ys,widths)))]
            d.polygon(p,fill=PAL[role])
    if t<25:packet(head-length,head,1)
    else:
        p=(t-25)/19
        packet(head-length,head-length*.52,1-p*.8,8*p)
        packet(head-length*.34,head,1-p*.72,-17*p)
    # Delay and drift three discrete trailing streamlets, with a deterministic lifetime.
    for k in range(3):
        age=t-(19+4*k)
        if 0<=age<18:
            x=61+12*k+2.1*age; y=43+(-1)**k*(5+age*.8); r=max(1,4-age*.18)
            d.polygon([(x-r,y),(x,y-r*.55),(x+r*1.8,y-.5),(x+r*.5,y+r*.65)],fill=PAL[3 if age<5 else 0])
    return im

def components(mask):
    pending=set(map(tuple,np.argwhere(mask))); count=0
    while pending:
        count+=1; q=[pending.pop()]
        while q:
            y,x=q.pop()
            for p in ((y-1,x),(y+1,x),(y,x-1),(y,x+1)):
                if p in pending:pending.remove(p);q.append(p)
    return count

def stats(im):
    arr=np.array(im);m=arr[:,:,3]>0;ys,xs=np.where(m)
    return dict(occupied=int(m.sum()),components=components(m),centroid_x=round(float(xs.mean()),3) if len(xs) else None,bounds=[int(xs.min()),int(ys.min()),int(xs.max()+1),int(ys.max()+1)] if len(xs) else None,rgba_sha256=hashlib.sha256(arr.tobytes()).hexdigest())

def view(im):
    b=Image.new('RGBA',(W,H),BG+(255,));b.alpha_composite(im);return b.convert('RGB').resize((W*S,H*S),Image.Resampling.NEAREST)

def run(out):
    out.mkdir(parents=True,exist_ok=True)
    renderers={'authored':manual,'procedural':procedural}
    frames={k:[f(t) for t in range(T)] for k,f in renderers.items()}
    result={k:[stats(im) for im in fs] for k,fs in frames.items()}
    checks={}
    for k,fs in frames.items():
        a=result[k];checks[k+'_blank_endpoints']=a[0]['occupied']==a[-1]['occupied']==0
        checks[k+'_directional_centroid']=a[36]['centroid_x']>a[12]['centroid_x']+25
        checks[k+'_separation']=max(x['components'] for x in a[24:40])>=2
        checks[k+'_palette']=all(set(map(tuple,np.array(im).reshape(-1,4)))<=set(PAL+[(0,0,0,0)]) for im in fs)
        checks[k+'_logical_blocks']=all(np.all((z:=np.array(view(im)))==z[::S,::S].repeat(S,0).repeat(S,1)) for im in fs)
    checks['authored_exposure']=all(len({result['authored'][t+j]['rgba_sha256'] for j in range(4)})==1 for t in range(0,T,4))
    checks['independent_render_difference']=all(result['authored'][t]['rgba_sha256']!=result['procedural'][t]['rgba_sha256'] for t in range(8,40))
    assert all(checks.values()),checks
    # Export native transparent fixed-cell sheets (8 columns, 6 rows) and frame map.
    for k,fs in frames.items():
        sheet=Image.new('RGBA',(W*8,H*6))
        for t,im in enumerate(fs):sheet.paste(im,((t%8)*W,(t//8)*H))
        sheet.save(out/(k+'-sheet.png'))
    font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',18)
    title=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',24)
    # Two side by side panels, original frames at 2x; explicit loop end.
    def pair(t):
        im=Image.new('RGB',(680,244),BG);d=ImageDraw.Draw(im);d.text((12,9),'SHEARWAKE  /  G06-P06',font=title,fill=(225,237,237));d.text((555,15),f'{t:02d}/47',font=font,fill=(151,178,188))
        for i,k in enumerate(frames):
            x=12+i*334;d.text((x,44),k.upper(),font=font,fill=(185,211,215));im.paste(view(frames[k][t]).resize((320,180),Image.Resampling.NEAREST),(x,64))
        return im
    seq=[pair(t) for t in range(T)];seq[0].save(out/'shearwake.gif',save_all=True,append_images=seq[1:],duration=[50 if t%6==5 else 40 for t in range(T)],loop=0,disposal=2)
    ticks=[8,16,24,28,32,40];contact=Image.new('RGB',(1080,544),BG);d=ImageDraw.Draw(contact);d.text((18,14),'SHEARWAKE  /  CONTOUR & FLOW',font=title,fill=(225,237,237));
    for j,t in enumerate(ticks):
        x=99+j*162;d.text((x,58),f'TICK {t:02d}',font=font,fill=(151,178,188))
        for i,k in enumerate(frames):
            y=92+i*220;contact.paste(view(frames[k][t]).resize((160,90),Image.Resampling.NEAREST),(x,y));d.text((x,y+103),f'{result[k][t]["occupied"]} px',font=font,fill=(151,178,188));d.text((x,y+128),f'{result[k][t]["components"]} regions',font=font,fill=(151,178,188))
    d.text((9,96),'DRAWN',font=font,fill=(225,237,237));d.text((9,316),'FLOW',font=font,fill=(225,237,237));contact=contact.crop((0,0,1080,478));contact.save(out/'contact-sheet.png')
    summary={k:{'unique_frames':len({r['rgba_sha256'] for r in v}),'peak_occupied':max(r['occupied'] for r in v),'peak_components':max(r['components'] for r in v),'centroid_x_12':v[12]['centroid_x'],'centroid_x_36':v[36]['centroid_x']} for k,v in result.items()}
    report={'size':[W,H],'scale':S,'ticks':T,'hz':24,'checks':checks,'summary':summary,'frames':result};(out/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'checks':checks,'summary':summary},indent=2))
if __name__=='__main__':run(Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parent)
